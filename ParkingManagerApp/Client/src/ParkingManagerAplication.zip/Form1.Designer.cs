﻿namespace $safeprojectname$
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.loadGarageResultField = new System.Windows.Forms.Label();
            this.loadGarageResultLabel = new System.Windows.Forms.Label();
            this.loadedGarageBuildingNumberField = new System.Windows.Forms.Label();
            this.loadedGarageStreetField = new System.Windows.Forms.Label();
            this.loadedGarageCityField = new System.Windows.Forms.Label();
            this.loadedGarageIdField = new System.Windows.Forms.Label();
            this.loadGarageBuildingNumberLabel = new System.Windows.Forms.Label();
            this.loadedGarageStreetLabel = new System.Windows.Forms.Label();
            this.loadedGarageCityLabel = new System.Windows.Forms.Label();
            this.loadedGarageIdLabel = new System.Windows.Forms.Label();
            this.loadGarageByIdButton = new System.Windows.Forms.Button();
            this.garageIDLabel = new System.Windows.Forms.Label();
            this.LoadGarageIdTextField = new System.Windows.Forms.TextBox();
            this.addNewGarageResultLabel = new System.Windows.Forms.TabPage();
            this.addNewGarageResultField = new System.Windows.Forms.Label();
            this.addGarageResultLabel = new System.Windows.Forms.Label();
            this.addNewGarageButton = new System.Windows.Forms.Button();
            this.newGarageBuildingLabel = new System.Windows.Forms.Label();
            this.newStreetBuildingLabel = new System.Windows.Forms.Label();
            this.newCityBuildingLabel = new System.Windows.Forms.Label();
            this.addGarageBuildingField = new System.Windows.Forms.TextBox();
            this.addGarageStreetField = new System.Windows.Forms.TextBox();
            this.addGarageCityField = new System.Windows.Forms.TextBox();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.deleteGarageResultField = new System.Windows.Forms.Label();
            this.deleteGarageResultLabel = new System.Windows.Forms.Label();
            this.deleteGarageButton = new System.Windows.Forms.Button();
            this.deleteGarageIdLabel = new System.Windows.Forms.Label();
            this.deleteGarageIdField = new System.Windows.Forms.TextBox();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.updateGarageResultField = new System.Windows.Forms.Label();
            this.updateGarageResultLabel = new System.Windows.Forms.Label();
            this.updateGarageNewData = new System.Windows.Forms.TextBox();
            this.updateGarageNewDataField = new System.Windows.Forms.Label();
            this.updateGarageIdFieldLabel = new System.Windows.Forms.Label();
            this.updateGarageButton = new System.Windows.Forms.Button();
            this.updateGarageIdTextField = new System.Windows.Forms.TextBox();
            this.updateGarageByBuildingNumberRadioButton = new System.Windows.Forms.RadioButton();
            this.updateGarageByStreetRadioButton = new System.Windows.Forms.RadioButton();
            this.updateGarageByCityRadioButton = new System.Windows.Forms.RadioButton();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.loadCarResultField = new System.Windows.Forms.Label();
            this.loadCarResultLabel = new System.Windows.Forms.Label();
            this.loadedCarOwnerIdField = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.loadedCarColorFIeld = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.loadedCarPlateNumberField = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.loadedCarYearField = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.loadedCarModelField = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.loadedCarBrandField = new System.Windows.Forms.Label();
            this.loadedCarBrandLabel = new System.Windows.Forms.Label();
            this.loadedCarIdField = new System.Windows.Forms.Label();
            this.loadedCarIdLabel = new System.Windows.Forms.Label();
            this.loadCarButton = new System.Windows.Forms.Button();
            this.loadCarIdLabel = new System.Windows.Forms.Label();
            this.loadCarIdTextField = new System.Windows.Forms.TextBox();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.addCarResultField = new System.Windows.Forms.Label();
            this.addCarResultLabel = new System.Windows.Forms.Label();
            this.addCarGarageFieldLabel = new System.Windows.Forms.Label();
            this.addCarGarageIdField = new System.Windows.Forms.TextBox();
            this.addNewCarOwnerFieldLabel = new System.Windows.Forms.Label();
            this.addNewCarOwnerIdField = new System.Windows.Forms.TextBox();
            this.addNewCarColorFieldLabel = new System.Windows.Forms.Label();
            this.addNewCarPlateNumberFieldLabel = new System.Windows.Forms.Label();
            this.addNewCarColorField = new System.Windows.Forms.TextBox();
            this.addNewCarPlateNumberField = new System.Windows.Forms.TextBox();
            this.addNewCarButon = new System.Windows.Forms.Button();
            this.addNewCarYearFieldLabel = new System.Windows.Forms.Label();
            this.addNewCarModelFieldLabel = new System.Windows.Forms.Label();
            this.addNewCarBrandFieldLabel = new System.Windows.Forms.Label();
            this.addNewCarYearField = new System.Windows.Forms.TextBox();
            this.addNewCarModelField = new System.Windows.Forms.TextBox();
            this.addNewCarBrandField = new System.Windows.Forms.TextBox();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.deleteCarResultField = new System.Windows.Forms.Label();
            this.DeleteCarResultLabel = new System.Windows.Forms.Label();
            this.deleteCarButton = new System.Windows.Forms.Button();
            this.deleteCarIdLabel = new System.Windows.Forms.Label();
            this.DeleteCarIdField = new System.Windows.Forms.TextBox();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.updateCarResultField = new System.Windows.Forms.Label();
            this.updateCarResultLabel = new System.Windows.Forms.Label();
            this.updateCarNewDataField = new System.Windows.Forms.TextBox();
            this.updateCarNewDataLabel = new System.Windows.Forms.Label();
            this.updateCarOwnerIdRadioButton = new System.Windows.Forms.RadioButton();
            this.updateCarColorRadioButton = new System.Windows.Forms.RadioButton();
            this.updateCarPlateNumberRadioButton = new System.Windows.Forms.RadioButton();
            this.updateCarIdFieldLabel = new System.Windows.Forms.Label();
            this.updateCarButton = new System.Windows.Forms.Button();
            this.updateCarIdField = new System.Windows.Forms.TextBox();
            this.updateCarYearRadioButton = new System.Windows.Forms.RadioButton();
            this.updateCarModelRadioButton = new System.Windows.Forms.RadioButton();
            this.updateCarBrandRadioButton = new System.Windows.Forms.RadioButton();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.loadOwnerResultField = new System.Windows.Forms.Label();
            this.loadOwnerResultLabel = new System.Windows.Forms.Label();
            this.loadedOwnerSurnameField = new System.Windows.Forms.Label();
            this.loadedOwnerSurnameLabel = new System.Windows.Forms.Label();
            this.loadedOwnerNameField = new System.Windows.Forms.Label();
            this.loadedOwnerIdField = new System.Windows.Forms.Label();
            this.loadedOwnerNameLabel = new System.Windows.Forms.Label();
            this.loadedOwnerIdLabel = new System.Windows.Forms.Label();
            this.loadOwnerIdButton = new System.Windows.Forms.Button();
            this.loadOwnerIdLabel = new System.Windows.Forms.Label();
            this.loadOwnerIdField = new System.Windows.Forms.TextBox();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.addNewOwnerResultField = new System.Windows.Forms.Label();
            this.addNewOwnerResultLabel = new System.Windows.Forms.Label();
            this.addNewOwnerButton = new System.Windows.Forms.Button();
            this.newOwnerSurnameLabel = new System.Windows.Forms.Label();
            this.addOwnerNameLabel = new System.Windows.Forms.Label();
            this.newOwnerSurnameField = new System.Windows.Forms.TextBox();
            this.newOwnerNameField = new System.Windows.Forms.TextBox();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.deleteOwnerResultField = new System.Windows.Forms.Label();
            this.deleteOwnerResultLabel = new System.Windows.Forms.Label();
            this.deleteOwnerIdButton = new System.Windows.Forms.Button();
            this.deleteOwnerIdLabel = new System.Windows.Forms.Label();
            this.deleteOwnerIdFIeld = new System.Windows.Forms.TextBox();
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.updateOwnerResultField = new System.Windows.Forms.Label();
            this.updateOwnerResultLabel = new System.Windows.Forms.Label();
            this.updateOwnerNewDataLabel = new System.Windows.Forms.Label();
            this.updateOwnerNewDataField = new System.Windows.Forms.TextBox();
            this.updateOwnerSurnameRadioButton = new System.Windows.Forms.RadioButton();
            this.updateOwnerNameRadioButton = new System.Windows.Forms.RadioButton();
            this.updateOwnerIdLabel = new System.Windows.Forms.Label();
            this.updateOwnerButton = new System.Windows.Forms.Button();
            this.updateOwnerIdField = new System.Windows.Forms.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.loadAllDataTreeView = new System.Windows.Forms.TreeView();
            this.addSampleDataButton = new System.Windows.Forms.Button();
            this.loadAllDataButton = new System.Windows.Forms.Button();
            this.tabPage17 = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.addNewGarageResultLabel.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.tabPage12.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabControl4.SuspendLayout();
            this.tabPage13.SuspendLayout();
            this.tabPage14.SuspendLayout();
            this.tabPage15.SuspendLayout();
            this.tabPage16.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage17.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage17);
            this.tabControl1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.tabControl1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(771, 423);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tabControl2);
            this.tabPage1.Location = new System.Drawing.Point(4, 27);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(763, 392);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Garage";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Controls.Add(this.addNewGarageResultLabel);
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage8);
            this.tabControl2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.tabControl2.Location = new System.Drawing.Point(0, 6);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(767, 395);
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.loadGarageResultField);
            this.tabPage5.Controls.Add(this.loadGarageResultLabel);
            this.tabPage5.Controls.Add(this.loadedGarageBuildingNumberField);
            this.tabPage5.Controls.Add(this.loadedGarageStreetField);
            this.tabPage5.Controls.Add(this.loadedGarageCityField);
            this.tabPage5.Controls.Add(this.loadedGarageIdField);
            this.tabPage5.Controls.Add(this.loadGarageBuildingNumberLabel);
            this.tabPage5.Controls.Add(this.loadedGarageStreetLabel);
            this.tabPage5.Controls.Add(this.loadedGarageCityLabel);
            this.tabPage5.Controls.Add(this.loadedGarageIdLabel);
            this.tabPage5.Controls.Add(this.loadGarageByIdButton);
            this.tabPage5.Controls.Add(this.garageIDLabel);
            this.tabPage5.Controls.Add(this.LoadGarageIdTextField);
            this.tabPage5.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.tabPage5.Location = new System.Drawing.Point(4, 27);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(759, 364);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "Load Garage";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // loadGarageResultField
            // 
            this.loadGarageResultField.AutoSize = true;
            this.loadGarageResultField.Location = new System.Drawing.Point(453, 153);
            this.loadGarageResultField.Name = "loadGarageResultField";
            this.loadGarageResultField.Size = new System.Drawing.Size(0, 18);
            this.loadGarageResultField.TabIndex = 13;
            // 
            // loadGarageResultLabel
            // 
            this.loadGarageResultLabel.AutoSize = true;
            this.loadGarageResultLabel.Location = new System.Drawing.Point(395, 153);
            this.loadGarageResultLabel.Name = "loadGarageResultLabel";
            this.loadGarageResultLabel.Size = new System.Drawing.Size(52, 18);
            this.loadGarageResultLabel.TabIndex = 12;
            this.loadGarageResultLabel.Text = "Result :";
            // 
            // loadedGarageBuildingNumberField
            // 
            this.loadedGarageBuildingNumberField.AutoSize = true;
            this.loadedGarageBuildingNumberField.Location = new System.Drawing.Point(454, 135);
            this.loadedGarageBuildingNumberField.Name = "loadedGarageBuildingNumberField";
            this.loadedGarageBuildingNumberField.Size = new System.Drawing.Size(0, 18);
            this.loadedGarageBuildingNumberField.TabIndex = 10;
            // 
            // loadedGarageStreetField
            // 
            this.loadedGarageStreetField.AutoSize = true;
            this.loadedGarageStreetField.Location = new System.Drawing.Point(454, 117);
            this.loadedGarageStreetField.Name = "loadedGarageStreetField";
            this.loadedGarageStreetField.Size = new System.Drawing.Size(0, 18);
            this.loadedGarageStreetField.TabIndex = 9;
            // 
            // loadedGarageCityField
            // 
            this.loadedGarageCityField.AutoSize = true;
            this.loadedGarageCityField.Location = new System.Drawing.Point(454, 98);
            this.loadedGarageCityField.Name = "loadedGarageCityField";
            this.loadedGarageCityField.Size = new System.Drawing.Size(0, 18);
            this.loadedGarageCityField.TabIndex = 8;
            // 
            // loadedGarageIdField
            // 
            this.loadedGarageIdField.AutoSize = true;
            this.loadedGarageIdField.Location = new System.Drawing.Point(454, 77);
            this.loadedGarageIdField.Name = "loadedGarageIdField";
            this.loadedGarageIdField.Size = new System.Drawing.Size(0, 18);
            this.loadedGarageIdField.TabIndex = 7;
            // 
            // loadGarageBuildingNumberLabel
            // 
            this.loadGarageBuildingNumberLabel.AutoSize = true;
            this.loadGarageBuildingNumberLabel.Location = new System.Drawing.Point(336, 135);
            this.loadGarageBuildingNumberLabel.Name = "loadGarageBuildingNumberLabel";
            this.loadGarageBuildingNumberLabel.Size = new System.Drawing.Size(112, 18);
            this.loadGarageBuildingNumberLabel.TabIndex = 6;
            this.loadGarageBuildingNumberLabel.Text = "Building Number :";
            // 
            // loadedGarageStreetLabel
            // 
            this.loadedGarageStreetLabel.AutoSize = true;
            this.loadedGarageStreetLabel.Location = new System.Drawing.Point(395, 117);
            this.loadedGarageStreetLabel.Name = "loadedGarageStreetLabel";
            this.loadedGarageStreetLabel.Size = new System.Drawing.Size(53, 18);
            this.loadedGarageStreetLabel.TabIndex = 5;
            this.loadedGarageStreetLabel.Text = "Street :";
            // 
            // loadedGarageCityLabel
            // 
            this.loadedGarageCityLabel.AutoSize = true;
            this.loadedGarageCityLabel.Location = new System.Drawing.Point(408, 95);
            this.loadedGarageCityLabel.Name = "loadedGarageCityLabel";
            this.loadedGarageCityLabel.Size = new System.Drawing.Size(40, 18);
            this.loadedGarageCityLabel.TabIndex = 4;
            this.loadedGarageCityLabel.Text = "City :";
            // 
            // loadedGarageIdLabel
            // 
            this.loadedGarageIdLabel.AutoSize = true;
            this.loadedGarageIdLabel.Location = new System.Drawing.Point(419, 77);
            this.loadedGarageIdLabel.Name = "loadedGarageIdLabel";
            this.loadedGarageIdLabel.Size = new System.Drawing.Size(29, 18);
            this.loadedGarageIdLabel.TabIndex = 3;
            this.loadedGarageIdLabel.Text = "ID :";
            // 
            // loadGarageByIdButton
            // 
            this.loadGarageByIdButton.Location = new System.Drawing.Point(146, 94);
            this.loadGarageByIdButton.Name = "loadGarageByIdButton";
            this.loadGarageByIdButton.Size = new System.Drawing.Size(160, 26);
            this.loadGarageByIdButton.TabIndex = 2;
            this.loadGarageByIdButton.Text = "Load Garage";
            this.loadGarageByIdButton.UseVisualStyleBackColor = true;
            this.loadGarageByIdButton.Click += new System.EventHandler(this.loadGarageByIdButton_Click);
            // 
            // garageIDLabel
            // 
            this.garageIDLabel.AutoSize = true;
            this.garageIDLabel.Location = new System.Drawing.Point(74, 68);
            this.garageIDLabel.Name = "garageIDLabel";
            this.garageIDLabel.Size = new System.Drawing.Size(66, 18);
            this.garageIDLabel.TabIndex = 1;
            this.garageIDLabel.Text = "Garage ID";
            // 
            // LoadGarageIdTextField
            // 
            this.LoadGarageIdTextField.Location = new System.Drawing.Point(146, 65);
            this.LoadGarageIdTextField.Name = "LoadGarageIdTextField";
            this.LoadGarageIdTextField.Size = new System.Drawing.Size(160, 23);
            this.LoadGarageIdTextField.TabIndex = 0;
            // 
            // addNewGarageResultLabel
            // 
            this.addNewGarageResultLabel.Controls.Add(this.addNewGarageResultField);
            this.addNewGarageResultLabel.Controls.Add(this.addGarageResultLabel);
            this.addNewGarageResultLabel.Controls.Add(this.addNewGarageButton);
            this.addNewGarageResultLabel.Controls.Add(this.newGarageBuildingLabel);
            this.addNewGarageResultLabel.Controls.Add(this.newStreetBuildingLabel);
            this.addNewGarageResultLabel.Controls.Add(this.newCityBuildingLabel);
            this.addNewGarageResultLabel.Controls.Add(this.addGarageBuildingField);
            this.addNewGarageResultLabel.Controls.Add(this.addGarageStreetField);
            this.addNewGarageResultLabel.Controls.Add(this.addGarageCityField);
            this.addNewGarageResultLabel.Location = new System.Drawing.Point(4, 27);
            this.addNewGarageResultLabel.Name = "addNewGarageResultLabel";
            this.addNewGarageResultLabel.Padding = new System.Windows.Forms.Padding(3);
            this.addNewGarageResultLabel.Size = new System.Drawing.Size(759, 364);
            this.addNewGarageResultLabel.TabIndex = 1;
            this.addNewGarageResultLabel.Text = "Add Garage";
            this.addNewGarageResultLabel.UseVisualStyleBackColor = true;
            // 
            // addNewGarageResultField
            // 
            this.addNewGarageResultField.AutoSize = true;
            this.addNewGarageResultField.Location = new System.Drawing.Point(442, 74);
            this.addNewGarageResultField.Name = "addNewGarageResultField";
            this.addNewGarageResultField.Size = new System.Drawing.Size(0, 18);
            this.addNewGarageResultField.TabIndex = 11;
            // 
            // addGarageResultLabel
            // 
            this.addGarageResultLabel.AutoSize = true;
            this.addGarageResultLabel.Location = new System.Drawing.Point(392, 72);
            this.addGarageResultLabel.Name = "addGarageResultLabel";
            this.addGarageResultLabel.Size = new System.Drawing.Size(52, 18);
            this.addGarageResultLabel.TabIndex = 10;
            this.addGarageResultLabel.Text = "Result :";
            // 
            // addNewGarageButton
            // 
            this.addNewGarageButton.Location = new System.Drawing.Point(149, 143);
            this.addNewGarageButton.Name = "addNewGarageButton";
            this.addNewGarageButton.Size = new System.Drawing.Size(160, 23);
            this.addNewGarageButton.TabIndex = 9;
            this.addNewGarageButton.Text = "Add Garage";
            this.addNewGarageButton.UseVisualStyleBackColor = true;
            this.addNewGarageButton.Click += new System.EventHandler(this.addNewGarageButton_Click);
            // 
            // newGarageBuildingLabel
            // 
            this.newGarageBuildingLabel.AutoSize = true;
            this.newGarageBuildingLabel.Location = new System.Drawing.Point(41, 120);
            this.newGarageBuildingLabel.Name = "newGarageBuildingLabel";
            this.newGarageBuildingLabel.Size = new System.Drawing.Size(102, 18);
            this.newGarageBuildingLabel.TabIndex = 8;
            this.newGarageBuildingLabel.Text = "Building number";
            // 
            // newStreetBuildingLabel
            // 
            this.newStreetBuildingLabel.AutoSize = true;
            this.newStreetBuildingLabel.Location = new System.Drawing.Point(99, 94);
            this.newStreetBuildingLabel.Name = "newStreetBuildingLabel";
            this.newStreetBuildingLabel.Size = new System.Drawing.Size(44, 18);
            this.newStreetBuildingLabel.TabIndex = 6;
            this.newStreetBuildingLabel.Text = "Street";
            // 
            // newCityBuildingLabel
            // 
            this.newCityBuildingLabel.AutoSize = true;
            this.newCityBuildingLabel.Location = new System.Drawing.Point(112, 68);
            this.newCityBuildingLabel.Name = "newCityBuildingLabel";
            this.newCityBuildingLabel.Size = new System.Drawing.Size(31, 18);
            this.newCityBuildingLabel.TabIndex = 5;
            this.newCityBuildingLabel.Text = "City";
            // 
            // addGarageBuildingField
            // 
            this.addGarageBuildingField.Location = new System.Drawing.Point(149, 117);
            this.addGarageBuildingField.Name = "addGarageBuildingField";
            this.addGarageBuildingField.Size = new System.Drawing.Size(160, 23);
            this.addGarageBuildingField.TabIndex = 3;
            // 
            // addGarageStreetField
            // 
            this.addGarageStreetField.Location = new System.Drawing.Point(149, 91);
            this.addGarageStreetField.Name = "addGarageStreetField";
            this.addGarageStreetField.Size = new System.Drawing.Size(160, 23);
            this.addGarageStreetField.TabIndex = 2;
            // 
            // addGarageCityField
            // 
            this.addGarageCityField.Location = new System.Drawing.Point(149, 65);
            this.addGarageCityField.Name = "addGarageCityField";
            this.addGarageCityField.Size = new System.Drawing.Size(160, 23);
            this.addGarageCityField.TabIndex = 1;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.deleteGarageResultField);
            this.tabPage7.Controls.Add(this.deleteGarageResultLabel);
            this.tabPage7.Controls.Add(this.deleteGarageButton);
            this.tabPage7.Controls.Add(this.deleteGarageIdLabel);
            this.tabPage7.Controls.Add(this.deleteGarageIdField);
            this.tabPage7.Location = new System.Drawing.Point(4, 27);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(759, 364);
            this.tabPage7.TabIndex = 2;
            this.tabPage7.Text = "Delete Garage";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // deleteGarageResultField
            // 
            this.deleteGarageResultField.AutoSize = true;
            this.deleteGarageResultField.Location = new System.Drawing.Point(439, 69);
            this.deleteGarageResultField.Name = "deleteGarageResultField";
            this.deleteGarageResultField.Size = new System.Drawing.Size(0, 18);
            this.deleteGarageResultField.TabIndex = 13;
            // 
            // deleteGarageResultLabel
            // 
            this.deleteGarageResultLabel.AutoSize = true;
            this.deleteGarageResultLabel.Location = new System.Drawing.Point(389, 67);
            this.deleteGarageResultLabel.Name = "deleteGarageResultLabel";
            this.deleteGarageResultLabel.Size = new System.Drawing.Size(52, 18);
            this.deleteGarageResultLabel.TabIndex = 12;
            this.deleteGarageResultLabel.Text = "Result :";
            // 
            // deleteGarageButton
            // 
            this.deleteGarageButton.Location = new System.Drawing.Point(148, 86);
            this.deleteGarageButton.Name = "deleteGarageButton";
            this.deleteGarageButton.Size = new System.Drawing.Size(160, 26);
            this.deleteGarageButton.TabIndex = 5;
            this.deleteGarageButton.Text = "Delete Garage";
            this.deleteGarageButton.UseVisualStyleBackColor = true;
            this.deleteGarageButton.Click += new System.EventHandler(this.deleteGarageButton_Click);
            // 
            // deleteGarageIdLabel
            // 
            this.deleteGarageIdLabel.AutoSize = true;
            this.deleteGarageIdLabel.Location = new System.Drawing.Point(76, 65);
            this.deleteGarageIdLabel.Name = "deleteGarageIdLabel";
            this.deleteGarageIdLabel.Size = new System.Drawing.Size(66, 18);
            this.deleteGarageIdLabel.TabIndex = 4;
            this.deleteGarageIdLabel.Text = "Garage ID";
            // 
            // deleteGarageIdField
            // 
            this.deleteGarageIdField.Location = new System.Drawing.Point(148, 60);
            this.deleteGarageIdField.Name = "deleteGarageIdField";
            this.deleteGarageIdField.Size = new System.Drawing.Size(160, 23);
            this.deleteGarageIdField.TabIndex = 3;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.updateGarageResultField);
            this.tabPage8.Controls.Add(this.updateGarageResultLabel);
            this.tabPage8.Controls.Add(this.updateGarageNewData);
            this.tabPage8.Controls.Add(this.updateGarageNewDataField);
            this.tabPage8.Controls.Add(this.updateGarageIdFieldLabel);
            this.tabPage8.Controls.Add(this.updateGarageButton);
            this.tabPage8.Controls.Add(this.updateGarageIdTextField);
            this.tabPage8.Controls.Add(this.updateGarageByBuildingNumberRadioButton);
            this.tabPage8.Controls.Add(this.updateGarageByStreetRadioButton);
            this.tabPage8.Controls.Add(this.updateGarageByCityRadioButton);
            this.tabPage8.Location = new System.Drawing.Point(4, 27);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(759, 364);
            this.tabPage8.TabIndex = 3;
            this.tabPage8.Text = "Update Garage";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // updateGarageResultField
            // 
            this.updateGarageResultField.AutoSize = true;
            this.updateGarageResultField.Location = new System.Drawing.Point(553, 285);
            this.updateGarageResultField.Name = "updateGarageResultField";
            this.updateGarageResultField.Size = new System.Drawing.Size(0, 18);
            this.updateGarageResultField.TabIndex = 15;
            // 
            // updateGarageResultLabel
            // 
            this.updateGarageResultLabel.AutoSize = true;
            this.updateGarageResultLabel.Location = new System.Drawing.Point(393, 70);
            this.updateGarageResultLabel.Name = "updateGarageResultLabel";
            this.updateGarageResultLabel.Size = new System.Drawing.Size(52, 18);
            this.updateGarageResultLabel.TabIndex = 14;
            this.updateGarageResultLabel.Text = "Result :";
            // 
            // updateGarageNewData
            // 
            this.updateGarageNewData.Location = new System.Drawing.Point(148, 131);
            this.updateGarageNewData.Name = "updateGarageNewData";
            this.updateGarageNewData.Size = new System.Drawing.Size(160, 23);
            this.updateGarageNewData.TabIndex = 7;
            // 
            // updateGarageNewDataField
            // 
            this.updateGarageNewDataField.AutoSize = true;
            this.updateGarageNewDataField.Location = new System.Drawing.Point(79, 134);
            this.updateGarageNewDataField.Name = "updateGarageNewDataField";
            this.updateGarageNewDataField.Size = new System.Drawing.Size(63, 18);
            this.updateGarageNewDataField.TabIndex = 6;
            this.updateGarageNewDataField.Text = "New Data";
            // 
            // updateGarageIdFieldLabel
            // 
            this.updateGarageIdFieldLabel.AutoSize = true;
            this.updateGarageIdFieldLabel.Location = new System.Drawing.Point(76, 160);
            this.updateGarageIdFieldLabel.Name = "updateGarageIdFieldLabel";
            this.updateGarageIdFieldLabel.Size = new System.Drawing.Size(66, 18);
            this.updateGarageIdFieldLabel.TabIndex = 5;
            this.updateGarageIdFieldLabel.Text = "Garage ID";
            // 
            // updateGarageButton
            // 
            this.updateGarageButton.Location = new System.Drawing.Point(148, 183);
            this.updateGarageButton.Name = "updateGarageButton";
            this.updateGarageButton.Size = new System.Drawing.Size(160, 23);
            this.updateGarageButton.TabIndex = 4;
            this.updateGarageButton.Text = "Upadate Garage";
            this.updateGarageButton.UseVisualStyleBackColor = true;
            this.updateGarageButton.Click += new System.EventHandler(this.updateGarageButton_Click);
            // 
            // updateGarageIdTextField
            // 
            this.updateGarageIdTextField.Location = new System.Drawing.Point(148, 157);
            this.updateGarageIdTextField.Name = "updateGarageIdTextField";
            this.updateGarageIdTextField.Size = new System.Drawing.Size(160, 23);
            this.updateGarageIdTextField.TabIndex = 3;
            // 
            // updateGarageByBuildingNumberRadioButton
            // 
            this.updateGarageByBuildingNumberRadioButton.AutoSize = true;
            this.updateGarageByBuildingNumberRadioButton.Location = new System.Drawing.Point(148, 103);
            this.updateGarageByBuildingNumberRadioButton.Name = "updateGarageByBuildingNumberRadioButton";
            this.updateGarageByBuildingNumberRadioButton.Size = new System.Drawing.Size(166, 22);
            this.updateGarageByBuildingNumberRadioButton.TabIndex = 2;
            this.updateGarageByBuildingNumberRadioButton.TabStop = true;
            this.updateGarageByBuildingNumberRadioButton.Text = "Update Building Number";
            this.updateGarageByBuildingNumberRadioButton.UseVisualStyleBackColor = true;
            // 
            // updateGarageByStreetRadioButton
            // 
            this.updateGarageByStreetRadioButton.AutoSize = true;
            this.updateGarageByStreetRadioButton.Location = new System.Drawing.Point(148, 80);
            this.updateGarageByStreetRadioButton.Name = "updateGarageByStreetRadioButton";
            this.updateGarageByStreetRadioButton.Size = new System.Drawing.Size(107, 22);
            this.updateGarageByStreetRadioButton.TabIndex = 1;
            this.updateGarageByStreetRadioButton.TabStop = true;
            this.updateGarageByStreetRadioButton.Text = "Update Street";
            this.updateGarageByStreetRadioButton.UseVisualStyleBackColor = true;
            // 
            // updateGarageByCityRadioButton
            // 
            this.updateGarageByCityRadioButton.AutoSize = true;
            this.updateGarageByCityRadioButton.Location = new System.Drawing.Point(148, 57);
            this.updateGarageByCityRadioButton.Name = "updateGarageByCityRadioButton";
            this.updateGarageByCityRadioButton.Size = new System.Drawing.Size(94, 22);
            this.updateGarageByCityRadioButton.TabIndex = 0;
            this.updateGarageByCityRadioButton.TabStop = true;
            this.updateGarageByCityRadioButton.Text = "Update City";
            this.updateGarageByCityRadioButton.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tabControl3);
            this.tabPage2.Location = new System.Drawing.Point(4, 27);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(763, 392);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Car";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage9);
            this.tabControl3.Controls.Add(this.tabPage10);
            this.tabControl3.Controls.Add(this.tabPage11);
            this.tabControl3.Controls.Add(this.tabPage12);
            this.tabControl3.Location = new System.Drawing.Point(-2, 6);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(769, 395);
            this.tabControl3.TabIndex = 1;
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.loadCarResultField);
            this.tabPage9.Controls.Add(this.loadCarResultLabel);
            this.tabPage9.Controls.Add(this.loadedCarOwnerIdField);
            this.tabPage9.Controls.Add(this.label12);
            this.tabPage9.Controls.Add(this.loadedCarColorFIeld);
            this.tabPage9.Controls.Add(this.label14);
            this.tabPage9.Controls.Add(this.loadedCarPlateNumberField);
            this.tabPage9.Controls.Add(this.label16);
            this.tabPage9.Controls.Add(this.loadedCarYearField);
            this.tabPage9.Controls.Add(this.label6);
            this.tabPage9.Controls.Add(this.loadedCarModelField);
            this.tabPage9.Controls.Add(this.label8);
            this.tabPage9.Controls.Add(this.loadedCarBrandField);
            this.tabPage9.Controls.Add(this.loadedCarBrandLabel);
            this.tabPage9.Controls.Add(this.loadedCarIdField);
            this.tabPage9.Controls.Add(this.loadedCarIdLabel);
            this.tabPage9.Controls.Add(this.loadCarButton);
            this.tabPage9.Controls.Add(this.loadCarIdLabel);
            this.tabPage9.Controls.Add(this.loadCarIdTextField);
            this.tabPage9.Location = new System.Drawing.Point(4, 27);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(761, 364);
            this.tabPage9.TabIndex = 0;
            this.tabPage9.Text = "Load Car";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // loadCarResultField
            // 
            this.loadCarResultField.AutoSize = true;
            this.loadCarResultField.Location = new System.Drawing.Point(428, 214);
            this.loadCarResultField.Name = "loadCarResultField";
            this.loadCarResultField.Size = new System.Drawing.Size(0, 18);
            this.loadCarResultField.TabIndex = 21;
            // 
            // loadCarResultLabel
            // 
            this.loadCarResultLabel.AutoSize = true;
            this.loadCarResultLabel.Location = new System.Drawing.Point(370, 214);
            this.loadCarResultLabel.Name = "loadCarResultLabel";
            this.loadCarResultLabel.Size = new System.Drawing.Size(52, 18);
            this.loadCarResultLabel.TabIndex = 20;
            this.loadCarResultLabel.Text = "Result :";
            // 
            // loadedCarOwnerIdField
            // 
            this.loadedCarOwnerIdField.AutoSize = true;
            this.loadedCarOwnerIdField.Location = new System.Drawing.Point(428, 186);
            this.loadedCarOwnerIdField.Name = "loadedCarOwnerIdField";
            this.loadedCarOwnerIdField.Size = new System.Drawing.Size(0, 18);
            this.loadedCarOwnerIdField.TabIndex = 19;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(352, 190);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(70, 18);
            this.label12.TabIndex = 18;
            this.label12.Text = "Owner ID :";
            // 
            // loadedCarColorFIeld
            // 
            this.loadedCarColorFIeld.AutoSize = true;
            this.loadedCarColorFIeld.Location = new System.Drawing.Point(428, 168);
            this.loadedCarColorFIeld.Name = "loadedCarColorFIeld";
            this.loadedCarColorFIeld.Size = new System.Drawing.Size(0, 18);
            this.loadedCarColorFIeld.TabIndex = 17;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(375, 168);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(47, 18);
            this.label14.TabIndex = 16;
            this.label14.Text = "Color :";
            // 
            // loadedCarPlateNumberField
            // 
            this.loadedCarPlateNumberField.AutoSize = true;
            this.loadedCarPlateNumberField.Location = new System.Drawing.Point(428, 146);
            this.loadedCarPlateNumberField.Name = "loadedCarPlateNumberField";
            this.loadedCarPlateNumberField.Size = new System.Drawing.Size(0, 18);
            this.loadedCarPlateNumberField.TabIndex = 15;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(327, 146);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(95, 18);
            this.label16.TabIndex = 14;
            this.label16.Text = "Plate Number :";
            // 
            // loadedCarYearField
            // 
            this.loadedCarYearField.AutoSize = true;
            this.loadedCarYearField.Location = new System.Drawing.Point(428, 124);
            this.loadedCarYearField.Name = "loadedCarYearField";
            this.loadedCarYearField.Size = new System.Drawing.Size(0, 18);
            this.loadedCarYearField.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(380, 124);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 18);
            this.label6.TabIndex = 12;
            this.label6.Text = "Year :";
            // 
            // loadedCarModelField
            // 
            this.loadedCarModelField.AutoSize = true;
            this.loadedCarModelField.Location = new System.Drawing.Point(428, 105);
            this.loadedCarModelField.Name = "loadedCarModelField";
            this.loadedCarModelField.Size = new System.Drawing.Size(0, 18);
            this.loadedCarModelField.TabIndex = 11;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(371, 105);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(51, 18);
            this.label8.TabIndex = 10;
            this.label8.Text = "Model :";
            // 
            // loadedCarBrandField
            // 
            this.loadedCarBrandField.AutoSize = true;
            this.loadedCarBrandField.Location = new System.Drawing.Point(425, 83);
            this.loadedCarBrandField.Name = "loadedCarBrandField";
            this.loadedCarBrandField.Size = new System.Drawing.Size(0, 18);
            this.loadedCarBrandField.TabIndex = 9;
            // 
            // loadedCarBrandLabel
            // 
            this.loadedCarBrandLabel.AutoSize = true;
            this.loadedCarBrandLabel.Location = new System.Drawing.Point(372, 83);
            this.loadedCarBrandLabel.Name = "loadedCarBrandLabel";
            this.loadedCarBrandLabel.Size = new System.Drawing.Size(50, 18);
            this.loadedCarBrandLabel.TabIndex = 8;
            this.loadedCarBrandLabel.Text = "Brand :";
            // 
            // loadedCarIdField
            // 
            this.loadedCarIdField.AutoSize = true;
            this.loadedCarIdField.Location = new System.Drawing.Point(422, 63);
            this.loadedCarIdField.Name = "loadedCarIdField";
            this.loadedCarIdField.Size = new System.Drawing.Size(0, 18);
            this.loadedCarIdField.TabIndex = 7;
            // 
            // loadedCarIdLabel
            // 
            this.loadedCarIdLabel.AutoSize = true;
            this.loadedCarIdLabel.Location = new System.Drawing.Point(392, 63);
            this.loadedCarIdLabel.Name = "loadedCarIdLabel";
            this.loadedCarIdLabel.Size = new System.Drawing.Size(33, 18);
            this.loadedCarIdLabel.TabIndex = 6;
            this.loadedCarIdLabel.Text = "ID : ";
            // 
            // loadCarButton
            // 
            this.loadCarButton.Location = new System.Drawing.Point(141, 87);
            this.loadCarButton.Name = "loadCarButton";
            this.loadCarButton.Size = new System.Drawing.Size(160, 26);
            this.loadCarButton.TabIndex = 5;
            this.loadCarButton.Text = "Load Car";
            this.loadCarButton.UseVisualStyleBackColor = true;
            this.loadCarButton.Click += new System.EventHandler(this.loadCarButton_Click);
            // 
            // loadCarIdLabel
            // 
            this.loadCarIdLabel.AutoSize = true;
            this.loadCarIdLabel.Location = new System.Drawing.Point(91, 63);
            this.loadCarIdLabel.Name = "loadCarIdLabel";
            this.loadCarIdLabel.Size = new System.Drawing.Size(44, 18);
            this.loadCarIdLabel.TabIndex = 4;
            this.loadCarIdLabel.Text = "Car ID";
            // 
            // loadCarIdTextField
            // 
            this.loadCarIdTextField.Location = new System.Drawing.Point(141, 60);
            this.loadCarIdTextField.Name = "loadCarIdTextField";
            this.loadCarIdTextField.Size = new System.Drawing.Size(160, 23);
            this.loadCarIdTextField.TabIndex = 3;
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.addCarResultField);
            this.tabPage10.Controls.Add(this.addCarResultLabel);
            this.tabPage10.Controls.Add(this.addCarGarageFieldLabel);
            this.tabPage10.Controls.Add(this.addCarGarageIdField);
            this.tabPage10.Controls.Add(this.addNewCarOwnerFieldLabel);
            this.tabPage10.Controls.Add(this.addNewCarOwnerIdField);
            this.tabPage10.Controls.Add(this.addNewCarColorFieldLabel);
            this.tabPage10.Controls.Add(this.addNewCarPlateNumberFieldLabel);
            this.tabPage10.Controls.Add(this.addNewCarColorField);
            this.tabPage10.Controls.Add(this.addNewCarPlateNumberField);
            this.tabPage10.Controls.Add(this.addNewCarButon);
            this.tabPage10.Controls.Add(this.addNewCarYearFieldLabel);
            this.tabPage10.Controls.Add(this.addNewCarModelFieldLabel);
            this.tabPage10.Controls.Add(this.addNewCarBrandFieldLabel);
            this.tabPage10.Controls.Add(this.addNewCarYearField);
            this.tabPage10.Controls.Add(this.addNewCarModelField);
            this.tabPage10.Controls.Add(this.addNewCarBrandField);
            this.tabPage10.Location = new System.Drawing.Point(4, 27);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(761, 364);
            this.tabPage10.TabIndex = 1;
            this.tabPage10.Text = "Add Car";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // addCarResultField
            // 
            this.addCarResultField.AutoSize = true;
            this.addCarResultField.Location = new System.Drawing.Point(403, 68);
            this.addCarResultField.Name = "addCarResultField";
            this.addCarResultField.Size = new System.Drawing.Size(0, 18);
            this.addCarResultField.TabIndex = 26;
            // 
            // addCarResultLabel
            // 
            this.addCarResultLabel.AutoSize = true;
            this.addCarResultLabel.Location = new System.Drawing.Point(380, 66);
            this.addCarResultLabel.Name = "addCarResultLabel";
            this.addCarResultLabel.Size = new System.Drawing.Size(52, 18);
            this.addCarResultLabel.TabIndex = 25;
            this.addCarResultLabel.Text = "Result :";
            // 
            // addCarGarageFieldLabel
            // 
            this.addCarGarageFieldLabel.AutoSize = true;
            this.addCarGarageFieldLabel.Location = new System.Drawing.Point(63, 218);
            this.addCarGarageFieldLabel.Name = "addCarGarageFieldLabel";
            this.addCarGarageFieldLabel.Size = new System.Drawing.Size(66, 18);
            this.addCarGarageFieldLabel.TabIndex = 24;
            this.addCarGarageFieldLabel.Text = "Garage ID";
            // 
            // addCarGarageIdField
            // 
            this.addCarGarageIdField.Location = new System.Drawing.Point(135, 215);
            this.addCarGarageIdField.Name = "addCarGarageIdField";
            this.addCarGarageIdField.Size = new System.Drawing.Size(160, 23);
            this.addCarGarageIdField.TabIndex = 23;
            // 
            // addNewCarOwnerFieldLabel
            // 
            this.addNewCarOwnerFieldLabel.AutoSize = true;
            this.addNewCarOwnerFieldLabel.Location = new System.Drawing.Point(68, 192);
            this.addNewCarOwnerFieldLabel.Name = "addNewCarOwnerFieldLabel";
            this.addNewCarOwnerFieldLabel.Size = new System.Drawing.Size(61, 18);
            this.addNewCarOwnerFieldLabel.TabIndex = 22;
            this.addNewCarOwnerFieldLabel.Text = "Owner ID";
            // 
            // addNewCarOwnerIdField
            // 
            this.addNewCarOwnerIdField.Location = new System.Drawing.Point(135, 189);
            this.addNewCarOwnerIdField.Name = "addNewCarOwnerIdField";
            this.addNewCarOwnerIdField.Size = new System.Drawing.Size(160, 23);
            this.addNewCarOwnerIdField.TabIndex = 21;
            // 
            // addNewCarColorFieldLabel
            // 
            this.addNewCarColorFieldLabel.AutoSize = true;
            this.addNewCarColorFieldLabel.Location = new System.Drawing.Point(91, 166);
            this.addNewCarColorFieldLabel.Name = "addNewCarColorFieldLabel";
            this.addNewCarColorFieldLabel.Size = new System.Drawing.Size(38, 18);
            this.addNewCarColorFieldLabel.TabIndex = 20;
            this.addNewCarColorFieldLabel.Text = "Color";
            // 
            // addNewCarPlateNumberFieldLabel
            // 
            this.addNewCarPlateNumberFieldLabel.AutoSize = true;
            this.addNewCarPlateNumberFieldLabel.Location = new System.Drawing.Point(44, 140);
            this.addNewCarPlateNumberFieldLabel.Name = "addNewCarPlateNumberFieldLabel";
            this.addNewCarPlateNumberFieldLabel.Size = new System.Drawing.Size(85, 18);
            this.addNewCarPlateNumberFieldLabel.TabIndex = 19;
            this.addNewCarPlateNumberFieldLabel.Text = "Plate number";
            // 
            // addNewCarColorField
            // 
            this.addNewCarColorField.Location = new System.Drawing.Point(135, 163);
            this.addNewCarColorField.Name = "addNewCarColorField";
            this.addNewCarColorField.Size = new System.Drawing.Size(160, 23);
            this.addNewCarColorField.TabIndex = 18;
            // 
            // addNewCarPlateNumberField
            // 
            this.addNewCarPlateNumberField.Location = new System.Drawing.Point(135, 137);
            this.addNewCarPlateNumberField.Name = "addNewCarPlateNumberField";
            this.addNewCarPlateNumberField.Size = new System.Drawing.Size(160, 23);
            this.addNewCarPlateNumberField.TabIndex = 17;
            // 
            // addNewCarButon
            // 
            this.addNewCarButon.Location = new System.Drawing.Point(135, 241);
            this.addNewCarButon.Name = "addNewCarButon";
            this.addNewCarButon.Size = new System.Drawing.Size(160, 23);
            this.addNewCarButon.TabIndex = 16;
            this.addNewCarButon.Text = "Add Car";
            this.addNewCarButon.UseVisualStyleBackColor = true;
            this.addNewCarButon.Click += new System.EventHandler(this.addNewCarButon_Click);
            // 
            // addNewCarYearFieldLabel
            // 
            this.addNewCarYearFieldLabel.AutoSize = true;
            this.addNewCarYearFieldLabel.Location = new System.Drawing.Point(96, 114);
            this.addNewCarYearFieldLabel.Name = "addNewCarYearFieldLabel";
            this.addNewCarYearFieldLabel.Size = new System.Drawing.Size(33, 18);
            this.addNewCarYearFieldLabel.TabIndex = 15;
            this.addNewCarYearFieldLabel.Text = "Year";
            // 
            // addNewCarModelFieldLabel
            // 
            this.addNewCarModelFieldLabel.AutoSize = true;
            this.addNewCarModelFieldLabel.Location = new System.Drawing.Point(87, 88);
            this.addNewCarModelFieldLabel.Name = "addNewCarModelFieldLabel";
            this.addNewCarModelFieldLabel.Size = new System.Drawing.Size(42, 18);
            this.addNewCarModelFieldLabel.TabIndex = 14;
            this.addNewCarModelFieldLabel.Text = "Model";
            // 
            // addNewCarBrandFieldLabel
            // 
            this.addNewCarBrandFieldLabel.AutoSize = true;
            this.addNewCarBrandFieldLabel.Location = new System.Drawing.Point(88, 62);
            this.addNewCarBrandFieldLabel.Name = "addNewCarBrandFieldLabel";
            this.addNewCarBrandFieldLabel.Size = new System.Drawing.Size(41, 18);
            this.addNewCarBrandFieldLabel.TabIndex = 13;
            this.addNewCarBrandFieldLabel.Text = "Brand";
            // 
            // addNewCarYearField
            // 
            this.addNewCarYearField.Location = new System.Drawing.Point(135, 111);
            this.addNewCarYearField.Name = "addNewCarYearField";
            this.addNewCarYearField.Size = new System.Drawing.Size(160, 23);
            this.addNewCarYearField.TabIndex = 12;
            // 
            // addNewCarModelField
            // 
            this.addNewCarModelField.Location = new System.Drawing.Point(135, 85);
            this.addNewCarModelField.Name = "addNewCarModelField";
            this.addNewCarModelField.Size = new System.Drawing.Size(160, 23);
            this.addNewCarModelField.TabIndex = 11;
            // 
            // addNewCarBrandField
            // 
            this.addNewCarBrandField.Location = new System.Drawing.Point(135, 59);
            this.addNewCarBrandField.Name = "addNewCarBrandField";
            this.addNewCarBrandField.Size = new System.Drawing.Size(160, 23);
            this.addNewCarBrandField.TabIndex = 10;
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.deleteCarResultField);
            this.tabPage11.Controls.Add(this.DeleteCarResultLabel);
            this.tabPage11.Controls.Add(this.deleteCarButton);
            this.tabPage11.Controls.Add(this.deleteCarIdLabel);
            this.tabPage11.Controls.Add(this.DeleteCarIdField);
            this.tabPage11.Location = new System.Drawing.Point(4, 27);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(761, 364);
            this.tabPage11.TabIndex = 2;
            this.tabPage11.Text = "Delete Car";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // deleteCarResultField
            // 
            this.deleteCarResultField.AutoSize = true;
            this.deleteCarResultField.Location = new System.Drawing.Point(420, 71);
            this.deleteCarResultField.Name = "deleteCarResultField";
            this.deleteCarResultField.Size = new System.Drawing.Size(0, 18);
            this.deleteCarResultField.TabIndex = 28;
            // 
            // DeleteCarResultLabel
            // 
            this.DeleteCarResultLabel.AutoSize = true;
            this.DeleteCarResultLabel.Location = new System.Drawing.Point(370, 69);
            this.DeleteCarResultLabel.Name = "DeleteCarResultLabel";
            this.DeleteCarResultLabel.Size = new System.Drawing.Size(52, 18);
            this.DeleteCarResultLabel.TabIndex = 27;
            this.DeleteCarResultLabel.Text = "Result :";
            // 
            // deleteCarButton
            // 
            this.deleteCarButton.Location = new System.Drawing.Point(135, 88);
            this.deleteCarButton.Name = "deleteCarButton";
            this.deleteCarButton.Size = new System.Drawing.Size(160, 26);
            this.deleteCarButton.TabIndex = 8;
            this.deleteCarButton.Text = "Delete Car";
            this.deleteCarButton.UseVisualStyleBackColor = true;
            this.deleteCarButton.Click += new System.EventHandler(this.deleteCarButton_Click);
            // 
            // deleteCarIdLabel
            // 
            this.deleteCarIdLabel.AutoSize = true;
            this.deleteCarIdLabel.Location = new System.Drawing.Point(85, 65);
            this.deleteCarIdLabel.Name = "deleteCarIdLabel";
            this.deleteCarIdLabel.Size = new System.Drawing.Size(44, 18);
            this.deleteCarIdLabel.TabIndex = 7;
            this.deleteCarIdLabel.Text = "Car ID";
            // 
            // DeleteCarIdField
            // 
            this.DeleteCarIdField.Location = new System.Drawing.Point(135, 62);
            this.DeleteCarIdField.Name = "DeleteCarIdField";
            this.DeleteCarIdField.Size = new System.Drawing.Size(160, 23);
            this.DeleteCarIdField.TabIndex = 6;
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.updateCarResultField);
            this.tabPage12.Controls.Add(this.updateCarResultLabel);
            this.tabPage12.Controls.Add(this.updateCarNewDataField);
            this.tabPage12.Controls.Add(this.updateCarNewDataLabel);
            this.tabPage12.Controls.Add(this.updateCarOwnerIdRadioButton);
            this.tabPage12.Controls.Add(this.updateCarColorRadioButton);
            this.tabPage12.Controls.Add(this.updateCarPlateNumberRadioButton);
            this.tabPage12.Controls.Add(this.updateCarIdFieldLabel);
            this.tabPage12.Controls.Add(this.updateCarButton);
            this.tabPage12.Controls.Add(this.updateCarIdField);
            this.tabPage12.Controls.Add(this.updateCarYearRadioButton);
            this.tabPage12.Controls.Add(this.updateCarModelRadioButton);
            this.tabPage12.Controls.Add(this.updateCarBrandRadioButton);
            this.tabPage12.Location = new System.Drawing.Point(4, 27);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage12.Size = new System.Drawing.Size(761, 364);
            this.tabPage12.TabIndex = 3;
            this.tabPage12.Text = "Update Car";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // updateCarResultField
            // 
            this.updateCarResultField.AutoSize = true;
            this.updateCarResultField.Location = new System.Drawing.Point(408, 46);
            this.updateCarResultField.Name = "updateCarResultField";
            this.updateCarResultField.Size = new System.Drawing.Size(0, 18);
            this.updateCarResultField.TabIndex = 48;
            // 
            // updateCarResultLabel
            // 
            this.updateCarResultLabel.AutoSize = true;
            this.updateCarResultLabel.Location = new System.Drawing.Point(358, 44);
            this.updateCarResultLabel.Name = "updateCarResultLabel";
            this.updateCarResultLabel.Size = new System.Drawing.Size(52, 18);
            this.updateCarResultLabel.TabIndex = 47;
            this.updateCarResultLabel.Text = "Result :";
            // 
            // updateCarNewDataField
            // 
            this.updateCarNewDataField.Location = new System.Drawing.Point(110, 180);
            this.updateCarNewDataField.Name = "updateCarNewDataField";
            this.updateCarNewDataField.Size = new System.Drawing.Size(160, 23);
            this.updateCarNewDataField.TabIndex = 46;
            // 
            // updateCarNewDataLabel
            // 
            this.updateCarNewDataLabel.AutoSize = true;
            this.updateCarNewDataLabel.Location = new System.Drawing.Point(41, 183);
            this.updateCarNewDataLabel.Name = "updateCarNewDataLabel";
            this.updateCarNewDataLabel.Size = new System.Drawing.Size(63, 18);
            this.updateCarNewDataLabel.TabIndex = 45;
            this.updateCarNewDataLabel.Text = "New Data";
            // 
            // updateCarOwnerIdRadioButton
            // 
            this.updateCarOwnerIdRadioButton.AutoSize = true;
            this.updateCarOwnerIdRadioButton.Location = new System.Drawing.Point(110, 155);
            this.updateCarOwnerIdRadioButton.Name = "updateCarOwnerIdRadioButton";
            this.updateCarOwnerIdRadioButton.Size = new System.Drawing.Size(124, 22);
            this.updateCarOwnerIdRadioButton.TabIndex = 44;
            this.updateCarOwnerIdRadioButton.TabStop = true;
            this.updateCarOwnerIdRadioButton.Text = "Update Owner ID";
            this.updateCarOwnerIdRadioButton.UseVisualStyleBackColor = true;
            // 
            // updateCarColorRadioButton
            // 
            this.updateCarColorRadioButton.AutoSize = true;
            this.updateCarColorRadioButton.Location = new System.Drawing.Point(110, 132);
            this.updateCarColorRadioButton.Name = "updateCarColorRadioButton";
            this.updateCarColorRadioButton.Size = new System.Drawing.Size(101, 22);
            this.updateCarColorRadioButton.TabIndex = 43;
            this.updateCarColorRadioButton.TabStop = true;
            this.updateCarColorRadioButton.Text = "Update Color";
            this.updateCarColorRadioButton.UseVisualStyleBackColor = true;
            // 
            // updateCarPlateNumberRadioButton
            // 
            this.updateCarPlateNumberRadioButton.AutoSize = true;
            this.updateCarPlateNumberRadioButton.Location = new System.Drawing.Point(110, 109);
            this.updateCarPlateNumberRadioButton.Name = "updateCarPlateNumberRadioButton";
            this.updateCarPlateNumberRadioButton.Size = new System.Drawing.Size(149, 22);
            this.updateCarPlateNumberRadioButton.TabIndex = 42;
            this.updateCarPlateNumberRadioButton.TabStop = true;
            this.updateCarPlateNumberRadioButton.Text = "Update Plate Number";
            this.updateCarPlateNumberRadioButton.UseVisualStyleBackColor = true;
            // 
            // updateCarIdFieldLabel
            // 
            this.updateCarIdFieldLabel.AutoSize = true;
            this.updateCarIdFieldLabel.Location = new System.Drawing.Point(60, 206);
            this.updateCarIdFieldLabel.Name = "updateCarIdFieldLabel";
            this.updateCarIdFieldLabel.Size = new System.Drawing.Size(44, 18);
            this.updateCarIdFieldLabel.TabIndex = 41;
            this.updateCarIdFieldLabel.Text = "Car ID";
            // 
            // updateCarButton
            // 
            this.updateCarButton.Location = new System.Drawing.Point(110, 232);
            this.updateCarButton.Name = "updateCarButton";
            this.updateCarButton.Size = new System.Drawing.Size(160, 23);
            this.updateCarButton.TabIndex = 40;
            this.updateCarButton.Text = "Update Car";
            this.updateCarButton.UseVisualStyleBackColor = true;
            this.updateCarButton.Click += new System.EventHandler(this.updateCarButton_Click);
            // 
            // updateCarIdField
            // 
            this.updateCarIdField.Location = new System.Drawing.Point(110, 206);
            this.updateCarIdField.Name = "updateCarIdField";
            this.updateCarIdField.Size = new System.Drawing.Size(160, 23);
            this.updateCarIdField.TabIndex = 39;
            // 
            // updateCarYearRadioButton
            // 
            this.updateCarYearRadioButton.AutoSize = true;
            this.updateCarYearRadioButton.Location = new System.Drawing.Point(110, 86);
            this.updateCarYearRadioButton.Name = "updateCarYearRadioButton";
            this.updateCarYearRadioButton.Size = new System.Drawing.Size(96, 22);
            this.updateCarYearRadioButton.TabIndex = 38;
            this.updateCarYearRadioButton.TabStop = true;
            this.updateCarYearRadioButton.Text = "Update Year";
            this.updateCarYearRadioButton.UseVisualStyleBackColor = true;
            // 
            // updateCarModelRadioButton
            // 
            this.updateCarModelRadioButton.AutoSize = true;
            this.updateCarModelRadioButton.Location = new System.Drawing.Point(110, 63);
            this.updateCarModelRadioButton.Name = "updateCarModelRadioButton";
            this.updateCarModelRadioButton.Size = new System.Drawing.Size(105, 22);
            this.updateCarModelRadioButton.TabIndex = 37;
            this.updateCarModelRadioButton.TabStop = true;
            this.updateCarModelRadioButton.Text = "Update Model";
            this.updateCarModelRadioButton.UseVisualStyleBackColor = true;
            // 
            // updateCarBrandRadioButton
            // 
            this.updateCarBrandRadioButton.AutoSize = true;
            this.updateCarBrandRadioButton.Location = new System.Drawing.Point(110, 40);
            this.updateCarBrandRadioButton.Name = "updateCarBrandRadioButton";
            this.updateCarBrandRadioButton.Size = new System.Drawing.Size(104, 22);
            this.updateCarBrandRadioButton.TabIndex = 36;
            this.updateCarBrandRadioButton.TabStop = true;
            this.updateCarBrandRadioButton.Text = "Update Brand";
            this.updateCarBrandRadioButton.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.tabControl4);
            this.tabPage3.Location = new System.Drawing.Point(4, 27);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(763, 392);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Owner";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabControl4
            // 
            this.tabControl4.Controls.Add(this.tabPage13);
            this.tabControl4.Controls.Add(this.tabPage14);
            this.tabControl4.Controls.Add(this.tabPage15);
            this.tabControl4.Controls.Add(this.tabPage16);
            this.tabControl4.Location = new System.Drawing.Point(-2, 3);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(769, 398);
            this.tabControl4.TabIndex = 1;
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.loadOwnerResultField);
            this.tabPage13.Controls.Add(this.loadOwnerResultLabel);
            this.tabPage13.Controls.Add(this.loadedOwnerSurnameField);
            this.tabPage13.Controls.Add(this.loadedOwnerSurnameLabel);
            this.tabPage13.Controls.Add(this.loadedOwnerNameField);
            this.tabPage13.Controls.Add(this.loadedOwnerIdField);
            this.tabPage13.Controls.Add(this.loadedOwnerNameLabel);
            this.tabPage13.Controls.Add(this.loadedOwnerIdLabel);
            this.tabPage13.Controls.Add(this.loadOwnerIdButton);
            this.tabPage13.Controls.Add(this.loadOwnerIdLabel);
            this.tabPage13.Controls.Add(this.loadOwnerIdField);
            this.tabPage13.Location = new System.Drawing.Point(4, 27);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage13.Size = new System.Drawing.Size(761, 367);
            this.tabPage13.TabIndex = 0;
            this.tabPage13.Text = "Load Owner";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // loadOwnerResultField
            // 
            this.loadOwnerResultField.AutoSize = true;
            this.loadOwnerResultField.Location = new System.Drawing.Point(422, 127);
            this.loadOwnerResultField.Name = "loadOwnerResultField";
            this.loadOwnerResultField.Size = new System.Drawing.Size(0, 18);
            this.loadOwnerResultField.TabIndex = 33;
            // 
            // loadOwnerResultLabel
            // 
            this.loadOwnerResultLabel.AutoSize = true;
            this.loadOwnerResultLabel.Location = new System.Drawing.Point(364, 127);
            this.loadOwnerResultLabel.Name = "loadOwnerResultLabel";
            this.loadOwnerResultLabel.Size = new System.Drawing.Size(52, 18);
            this.loadOwnerResultLabel.TabIndex = 32;
            this.loadOwnerResultLabel.Text = "Result :";
            // 
            // loadedOwnerSurnameField
            // 
            this.loadedOwnerSurnameField.AutoSize = true;
            this.loadedOwnerSurnameField.Location = new System.Drawing.Point(422, 103);
            this.loadedOwnerSurnameField.Name = "loadedOwnerSurnameField";
            this.loadedOwnerSurnameField.Size = new System.Drawing.Size(0, 18);
            this.loadedOwnerSurnameField.TabIndex = 11;
            // 
            // loadedOwnerSurnameLabel
            // 
            this.loadedOwnerSurnameLabel.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor;
            this.loadedOwnerSurnameLabel.AutoSize = true;
            this.loadedOwnerSurnameLabel.Location = new System.Drawing.Point(348, 103);
            this.loadedOwnerSurnameLabel.Name = "loadedOwnerSurnameLabel";
            this.loadedOwnerSurnameLabel.Size = new System.Drawing.Size(68, 18);
            this.loadedOwnerSurnameLabel.TabIndex = 10;
            this.loadedOwnerSurnameLabel.Text = "Surname :";
            // 
            // loadedOwnerNameField
            // 
            this.loadedOwnerNameField.AutoSize = true;
            this.loadedOwnerNameField.Location = new System.Drawing.Point(422, 85);
            this.loadedOwnerNameField.Name = "loadedOwnerNameField";
            this.loadedOwnerNameField.Size = new System.Drawing.Size(0, 18);
            this.loadedOwnerNameField.TabIndex = 9;
            // 
            // loadedOwnerIdField
            // 
            this.loadedOwnerIdField.AutoSize = true;
            this.loadedOwnerIdField.Location = new System.Drawing.Point(422, 62);
            this.loadedOwnerIdField.Name = "loadedOwnerIdField";
            this.loadedOwnerIdField.Size = new System.Drawing.Size(0, 18);
            this.loadedOwnerIdField.TabIndex = 8;
            // 
            // loadedOwnerNameLabel
            // 
            this.loadedOwnerNameLabel.AutoSize = true;
            this.loadedOwnerNameLabel.Location = new System.Drawing.Point(366, 83);
            this.loadedOwnerNameLabel.Name = "loadedOwnerNameLabel";
            this.loadedOwnerNameLabel.Size = new System.Drawing.Size(50, 18);
            this.loadedOwnerNameLabel.TabIndex = 7;
            this.loadedOwnerNameLabel.Text = "Name :";
            // 
            // loadedOwnerIdLabel
            // 
            this.loadedOwnerIdLabel.AutoSize = true;
            this.loadedOwnerIdLabel.Location = new System.Drawing.Point(350, 62);
            this.loadedOwnerIdLabel.Name = "loadedOwnerIdLabel";
            this.loadedOwnerIdLabel.Size = new System.Drawing.Size(66, 18);
            this.loadedOwnerIdLabel.TabIndex = 6;
            this.loadedOwnerIdLabel.Text = "Owner ID:";
            // 
            // loadOwnerIdButton
            // 
            this.loadOwnerIdButton.Location = new System.Drawing.Point(128, 81);
            this.loadOwnerIdButton.Name = "loadOwnerIdButton";
            this.loadOwnerIdButton.Size = new System.Drawing.Size(160, 26);
            this.loadOwnerIdButton.TabIndex = 5;
            this.loadOwnerIdButton.Text = "Load Owner";
            this.loadOwnerIdButton.UseVisualStyleBackColor = true;
            this.loadOwnerIdButton.Click += new System.EventHandler(this.loadOwnerIdButton_Click);
            // 
            // loadOwnerIdLabel
            // 
            this.loadOwnerIdLabel.AutoSize = true;
            this.loadOwnerIdLabel.Location = new System.Drawing.Point(61, 58);
            this.loadOwnerIdLabel.Name = "loadOwnerIdLabel";
            this.loadOwnerIdLabel.Size = new System.Drawing.Size(61, 18);
            this.loadOwnerIdLabel.TabIndex = 4;
            this.loadOwnerIdLabel.Text = "Owner ID";
            // 
            // loadOwnerIdField
            // 
            this.loadOwnerIdField.Location = new System.Drawing.Point(128, 55);
            this.loadOwnerIdField.Name = "loadOwnerIdField";
            this.loadOwnerIdField.Size = new System.Drawing.Size(160, 23);
            this.loadOwnerIdField.TabIndex = 3;
            // 
            // tabPage14
            // 
            this.tabPage14.Controls.Add(this.addNewOwnerResultField);
            this.tabPage14.Controls.Add(this.addNewOwnerResultLabel);
            this.tabPage14.Controls.Add(this.addNewOwnerButton);
            this.tabPage14.Controls.Add(this.newOwnerSurnameLabel);
            this.tabPage14.Controls.Add(this.addOwnerNameLabel);
            this.tabPage14.Controls.Add(this.newOwnerSurnameField);
            this.tabPage14.Controls.Add(this.newOwnerNameField);
            this.tabPage14.Location = new System.Drawing.Point(4, 27);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage14.Size = new System.Drawing.Size(761, 367);
            this.tabPage14.TabIndex = 1;
            this.tabPage14.Text = "Add Owner";
            this.tabPage14.UseVisualStyleBackColor = true;
            // 
            // addNewOwnerResultField
            // 
            this.addNewOwnerResultField.AutoSize = true;
            this.addNewOwnerResultField.Location = new System.Drawing.Point(397, 51);
            this.addNewOwnerResultField.Name = "addNewOwnerResultField";
            this.addNewOwnerResultField.Size = new System.Drawing.Size(0, 18);
            this.addNewOwnerResultField.TabIndex = 31;
            // 
            // addNewOwnerResultLabel
            // 
            this.addNewOwnerResultLabel.AutoSize = true;
            this.addNewOwnerResultLabel.Location = new System.Drawing.Point(347, 49);
            this.addNewOwnerResultLabel.Name = "addNewOwnerResultLabel";
            this.addNewOwnerResultLabel.Size = new System.Drawing.Size(52, 18);
            this.addNewOwnerResultLabel.TabIndex = 30;
            this.addNewOwnerResultLabel.Text = "Result :";
            // 
            // addNewOwnerButton
            // 
            this.addNewOwnerButton.Location = new System.Drawing.Point(131, 94);
            this.addNewOwnerButton.Name = "addNewOwnerButton";
            this.addNewOwnerButton.Size = new System.Drawing.Size(160, 23);
            this.addNewOwnerButton.TabIndex = 29;
            this.addNewOwnerButton.Text = "Add New Owner";
            this.addNewOwnerButton.UseVisualStyleBackColor = true;
            this.addNewOwnerButton.Click += new System.EventHandler(this.addNewOwnerButton_Click);
            // 
            // newOwnerSurnameLabel
            // 
            this.newOwnerSurnameLabel.AutoSize = true;
            this.newOwnerSurnameLabel.Location = new System.Drawing.Point(66, 71);
            this.newOwnerSurnameLabel.Name = "newOwnerSurnameLabel";
            this.newOwnerSurnameLabel.Size = new System.Drawing.Size(59, 18);
            this.newOwnerSurnameLabel.TabIndex = 27;
            this.newOwnerSurnameLabel.Text = "Surname";
            // 
            // addOwnerNameLabel
            // 
            this.addOwnerNameLabel.AutoSize = true;
            this.addOwnerNameLabel.Location = new System.Drawing.Point(84, 45);
            this.addOwnerNameLabel.Name = "addOwnerNameLabel";
            this.addOwnerNameLabel.Size = new System.Drawing.Size(41, 18);
            this.addOwnerNameLabel.TabIndex = 26;
            this.addOwnerNameLabel.Text = "Name";
            // 
            // newOwnerSurnameField
            // 
            this.newOwnerSurnameField.Location = new System.Drawing.Point(131, 68);
            this.newOwnerSurnameField.Name = "newOwnerSurnameField";
            this.newOwnerSurnameField.Size = new System.Drawing.Size(160, 23);
            this.newOwnerSurnameField.TabIndex = 24;
            // 
            // newOwnerNameField
            // 
            this.newOwnerNameField.Location = new System.Drawing.Point(131, 42);
            this.newOwnerNameField.Name = "newOwnerNameField";
            this.newOwnerNameField.Size = new System.Drawing.Size(160, 23);
            this.newOwnerNameField.TabIndex = 23;
            // 
            // tabPage15
            // 
            this.tabPage15.Controls.Add(this.deleteOwnerResultField);
            this.tabPage15.Controls.Add(this.deleteOwnerResultLabel);
            this.tabPage15.Controls.Add(this.deleteOwnerIdButton);
            this.tabPage15.Controls.Add(this.deleteOwnerIdLabel);
            this.tabPage15.Controls.Add(this.deleteOwnerIdFIeld);
            this.tabPage15.Location = new System.Drawing.Point(4, 27);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage15.Size = new System.Drawing.Size(761, 367);
            this.tabPage15.TabIndex = 2;
            this.tabPage15.Text = "Delete Owner";
            this.tabPage15.UseVisualStyleBackColor = true;
            // 
            // deleteOwnerResultField
            // 
            this.deleteOwnerResultField.AutoSize = true;
            this.deleteOwnerResultField.Location = new System.Drawing.Point(403, 58);
            this.deleteOwnerResultField.Name = "deleteOwnerResultField";
            this.deleteOwnerResultField.Size = new System.Drawing.Size(0, 18);
            this.deleteOwnerResultField.TabIndex = 33;
            // 
            // deleteOwnerResultLabel
            // 
            this.deleteOwnerResultLabel.AutoSize = true;
            this.deleteOwnerResultLabel.Location = new System.Drawing.Point(353, 56);
            this.deleteOwnerResultLabel.Name = "deleteOwnerResultLabel";
            this.deleteOwnerResultLabel.Size = new System.Drawing.Size(52, 18);
            this.deleteOwnerResultLabel.TabIndex = 32;
            this.deleteOwnerResultLabel.Text = "Result :";
            // 
            // deleteOwnerIdButton
            // 
            this.deleteOwnerIdButton.Location = new System.Drawing.Point(131, 75);
            this.deleteOwnerIdButton.Name = "deleteOwnerIdButton";
            this.deleteOwnerIdButton.Size = new System.Drawing.Size(160, 26);
            this.deleteOwnerIdButton.TabIndex = 8;
            this.deleteOwnerIdButton.Text = "Delete Owner";
            this.deleteOwnerIdButton.UseVisualStyleBackColor = true;
            this.deleteOwnerIdButton.Click += new System.EventHandler(this.deleteOwnerIdButton_Click);
            // 
            // deleteOwnerIdLabel
            // 
            this.deleteOwnerIdLabel.AutoSize = true;
            this.deleteOwnerIdLabel.Location = new System.Drawing.Point(64, 52);
            this.deleteOwnerIdLabel.Name = "deleteOwnerIdLabel";
            this.deleteOwnerIdLabel.Size = new System.Drawing.Size(61, 18);
            this.deleteOwnerIdLabel.TabIndex = 7;
            this.deleteOwnerIdLabel.Text = "Owner ID";
            // 
            // deleteOwnerIdFIeld
            // 
            this.deleteOwnerIdFIeld.Location = new System.Drawing.Point(131, 49);
            this.deleteOwnerIdFIeld.Name = "deleteOwnerIdFIeld";
            this.deleteOwnerIdFIeld.Size = new System.Drawing.Size(160, 23);
            this.deleteOwnerIdFIeld.TabIndex = 6;
            // 
            // tabPage16
            // 
            this.tabPage16.Controls.Add(this.updateOwnerResultField);
            this.tabPage16.Controls.Add(this.updateOwnerResultLabel);
            this.tabPage16.Controls.Add(this.updateOwnerNewDataLabel);
            this.tabPage16.Controls.Add(this.updateOwnerNewDataField);
            this.tabPage16.Controls.Add(this.updateOwnerSurnameRadioButton);
            this.tabPage16.Controls.Add(this.updateOwnerNameRadioButton);
            this.tabPage16.Controls.Add(this.updateOwnerIdLabel);
            this.tabPage16.Controls.Add(this.updateOwnerButton);
            this.tabPage16.Controls.Add(this.updateOwnerIdField);
            this.tabPage16.Location = new System.Drawing.Point(4, 27);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage16.Size = new System.Drawing.Size(761, 367);
            this.tabPage16.TabIndex = 3;
            this.tabPage16.Text = "Update Owner";
            this.tabPage16.UseVisualStyleBackColor = true;
            // 
            // updateOwnerResultField
            // 
            this.updateOwnerResultField.AutoSize = true;
            this.updateOwnerResultField.Location = new System.Drawing.Point(402, 40);
            this.updateOwnerResultField.Name = "updateOwnerResultField";
            this.updateOwnerResultField.Size = new System.Drawing.Size(0, 18);
            this.updateOwnerResultField.TabIndex = 57;
            // 
            // updateOwnerResultLabel
            // 
            this.updateOwnerResultLabel.AutoSize = true;
            this.updateOwnerResultLabel.Location = new System.Drawing.Point(352, 38);
            this.updateOwnerResultLabel.Name = "updateOwnerResultLabel";
            this.updateOwnerResultLabel.Size = new System.Drawing.Size(52, 18);
            this.updateOwnerResultLabel.TabIndex = 56;
            this.updateOwnerResultLabel.Text = "Result :";
            // 
            // updateOwnerNewDataLabel
            // 
            this.updateOwnerNewDataLabel.AutoSize = true;
            this.updateOwnerNewDataLabel.Location = new System.Drawing.Point(65, 83);
            this.updateOwnerNewDataLabel.Name = "updateOwnerNewDataLabel";
            this.updateOwnerNewDataLabel.Size = new System.Drawing.Size(63, 18);
            this.updateOwnerNewDataLabel.TabIndex = 55;
            this.updateOwnerNewDataLabel.Text = "New Data";
            // 
            // updateOwnerNewDataField
            // 
            this.updateOwnerNewDataField.Location = new System.Drawing.Point(134, 80);
            this.updateOwnerNewDataField.Name = "updateOwnerNewDataField";
            this.updateOwnerNewDataField.Size = new System.Drawing.Size(160, 23);
            this.updateOwnerNewDataField.TabIndex = 54;
            // 
            // updateOwnerSurnameRadioButton
            // 
            this.updateOwnerSurnameRadioButton.AutoSize = true;
            this.updateOwnerSurnameRadioButton.Location = new System.Drawing.Point(134, 57);
            this.updateOwnerSurnameRadioButton.Name = "updateOwnerSurnameRadioButton";
            this.updateOwnerSurnameRadioButton.Size = new System.Drawing.Size(122, 22);
            this.updateOwnerSurnameRadioButton.TabIndex = 53;
            this.updateOwnerSurnameRadioButton.TabStop = true;
            this.updateOwnerSurnameRadioButton.Text = "Update Surname";
            this.updateOwnerSurnameRadioButton.UseVisualStyleBackColor = true;
            // 
            // updateOwnerNameRadioButton
            // 
            this.updateOwnerNameRadioButton.AutoSize = true;
            this.updateOwnerNameRadioButton.Location = new System.Drawing.Point(134, 34);
            this.updateOwnerNameRadioButton.Name = "updateOwnerNameRadioButton";
            this.updateOwnerNameRadioButton.Size = new System.Drawing.Size(104, 22);
            this.updateOwnerNameRadioButton.TabIndex = 52;
            this.updateOwnerNameRadioButton.TabStop = true;
            this.updateOwnerNameRadioButton.Text = "Update Name";
            this.updateOwnerNameRadioButton.UseVisualStyleBackColor = true;
            // 
            // updateOwnerIdLabel
            // 
            this.updateOwnerIdLabel.AutoSize = true;
            this.updateOwnerIdLabel.Location = new System.Drawing.Point(67, 109);
            this.updateOwnerIdLabel.Name = "updateOwnerIdLabel";
            this.updateOwnerIdLabel.Size = new System.Drawing.Size(61, 18);
            this.updateOwnerIdLabel.TabIndex = 50;
            this.updateOwnerIdLabel.Text = "Owner ID";
            // 
            // updateOwnerButton
            // 
            this.updateOwnerButton.Location = new System.Drawing.Point(134, 132);
            this.updateOwnerButton.Name = "updateOwnerButton";
            this.updateOwnerButton.Size = new System.Drawing.Size(160, 23);
            this.updateOwnerButton.TabIndex = 49;
            this.updateOwnerButton.Text = "Update Owner";
            this.updateOwnerButton.UseVisualStyleBackColor = true;
            this.updateOwnerButton.Click += new System.EventHandler(this.updateOwnerButton_Click);
            // 
            // updateOwnerIdField
            // 
            this.updateOwnerIdField.Location = new System.Drawing.Point(134, 106);
            this.updateOwnerIdField.Name = "updateOwnerIdField";
            this.updateOwnerIdField.Size = new System.Drawing.Size(160, 23);
            this.updateOwnerIdField.TabIndex = 48;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.loadAllDataTreeView);
            this.tabPage4.Controls.Add(this.addSampleDataButton);
            this.tabPage4.Controls.Add(this.loadAllDataButton);
            this.tabPage4.Location = new System.Drawing.Point(4, 27);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(763, 392);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Load All Data";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // loadAllDataTreeView
            // 
            this.loadAllDataTreeView.Location = new System.Drawing.Point(340, 6);
            this.loadAllDataTreeView.Name = "loadAllDataTreeView";
            this.loadAllDataTreeView.Size = new System.Drawing.Size(417, 385);
            this.loadAllDataTreeView.TabIndex = 2;
            // 
            // addSampleDataButton
            // 
            this.addSampleDataButton.Location = new System.Drawing.Point(113, 218);
            this.addSampleDataButton.Name = "addSampleDataButton";
            this.addSampleDataButton.Size = new System.Drawing.Size(99, 74);
            this.addSampleDataButton.TabIndex = 1;
            this.addSampleDataButton.Text = "Add Sample Data ";
            this.addSampleDataButton.UseVisualStyleBackColor = true;
            this.addSampleDataButton.Click += new System.EventHandler(this.addSampleDataButton_Click);
            // 
            // loadAllDataButton
            // 
            this.loadAllDataButton.Location = new System.Drawing.Point(112, 64);
            this.loadAllDataButton.Name = "loadAllDataButton";
            this.loadAllDataButton.Size = new System.Drawing.Size(100, 74);
            this.loadAllDataButton.TabIndex = 0;
            this.loadAllDataButton.Text = "Load ALL";
            this.loadAllDataButton.UseVisualStyleBackColor = true;
            this.loadAllDataButton.Click += new System.EventHandler(this.loadAllDataButton_Click);
            // 
            // tabPage17
            // 
            this.tabPage17.Controls.Add(this.label9);
            this.tabPage17.Controls.Add(this.label7);
            this.tabPage17.Controls.Add(this.label5);
            this.tabPage17.Controls.Add(this.label4);
            this.tabPage17.Controls.Add(this.label3);
            this.tabPage17.Controls.Add(this.label2);
            this.tabPage17.Controls.Add(this.label1);
            this.tabPage17.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage17.Location = new System.Drawing.Point(4, 27);
            this.tabPage17.Name = "tabPage17";
            this.tabPage17.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage17.Size = new System.Drawing.Size(763, 392);
            this.tabPage17.TabIndex = 4;
            this.tabPage17.Text = "About This App";
            this.tabPage17.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(360, 362);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 22);
            this.label2.TabIndex = 1;
            this.label2.Text = "2016";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Trebuchet MS", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(222, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(289, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "Parking Manager Desktop App";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(144, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(448, 18);
            this.label3.TabIndex = 2;
            this.label3.Text = "This program provides an opportunity to manage garages, cars and owners";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(153, 101);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(426, 18);
            this.label4.TabIndex = 3;
            this.label4.Text = "in the database by SOAP Web services written in Java using Hibernate.";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(131, 153);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(491, 18);
            this.label5.TabIndex = 4;
            this.label5.Text = "In the \"Load All Data\" tab you can add some data for testing application. \"Load A" +
    "ll\"";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(131, 182);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(287, 18);
            this.label7.TabIndex = 5;
            this.label7.Text = " button in the same tab , display data in a tree ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(118, 230);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(521, 18);
            this.label9.TabIndex = 6;
            this.label9.Text = "Other tabs allow you to load, update, delete and create garages, cars and their o" +
    "wners.";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(795, 447);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(811, 486);
            this.MinimumSize = new System.Drawing.Size(811, 486);
            this.Name = "MainForm";
            this.Text = "Parking Manager Desktop App";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.addNewGarageResultLabel.ResumeLayout(false);
            this.addNewGarageResultLabel.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            this.tabPage10.ResumeLayout(false);
            this.tabPage10.PerformLayout();
            this.tabPage11.ResumeLayout(false);
            this.tabPage11.PerformLayout();
            this.tabPage12.ResumeLayout(false);
            this.tabPage12.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabControl4.ResumeLayout(false);
            this.tabPage13.ResumeLayout(false);
            this.tabPage13.PerformLayout();
            this.tabPage14.ResumeLayout(false);
            this.tabPage14.PerformLayout();
            this.tabPage15.ResumeLayout(false);
            this.tabPage15.PerformLayout();
            this.tabPage16.ResumeLayout(false);
            this.tabPage16.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage17.ResumeLayout(false);
            this.tabPage17.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Button loadGarageByIdButton;
        private System.Windows.Forms.Label garageIDLabel;
        private System.Windows.Forms.TextBox LoadGarageIdTextField;
        private System.Windows.Forms.TabPage addNewGarageResultLabel;
        private System.Windows.Forms.Button addNewGarageButton;
        private System.Windows.Forms.Label newGarageBuildingLabel;
        private System.Windows.Forms.Label newStreetBuildingLabel;
        private System.Windows.Forms.Label newCityBuildingLabel;
        private System.Windows.Forms.TextBox addGarageBuildingField;
        private System.Windows.Forms.TextBox addGarageStreetField;
        private System.Windows.Forms.TextBox addGarageCityField;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Button deleteGarageButton;
        private System.Windows.Forms.Label deleteGarageIdLabel;
        private System.Windows.Forms.TextBox deleteGarageIdField;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TextBox updateGarageNewData;
        private System.Windows.Forms.Label updateGarageNewDataField;
        private System.Windows.Forms.Label updateGarageIdFieldLabel;
        private System.Windows.Forms.Button updateGarageButton;
        private System.Windows.Forms.TextBox updateGarageIdTextField;
        private System.Windows.Forms.RadioButton updateGarageByBuildingNumberRadioButton;
        private System.Windows.Forms.RadioButton updateGarageByStreetRadioButton;
        private System.Windows.Forms.RadioButton updateGarageByCityRadioButton;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.Button loadCarButton;
        private System.Windows.Forms.Label loadCarIdLabel;
        private System.Windows.Forms.TextBox loadCarIdTextField;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.Label addCarGarageFieldLabel;
        private System.Windows.Forms.TextBox addCarGarageIdField;
        private System.Windows.Forms.Label addNewCarOwnerFieldLabel;
        private System.Windows.Forms.TextBox addNewCarOwnerIdField;
        private System.Windows.Forms.Label addNewCarColorFieldLabel;
        private System.Windows.Forms.Label addNewCarPlateNumberFieldLabel;
        private System.Windows.Forms.TextBox addNewCarColorField;
        private System.Windows.Forms.TextBox addNewCarPlateNumberField;
        private System.Windows.Forms.Button addNewCarButon;
        private System.Windows.Forms.Label addNewCarYearFieldLabel;
        private System.Windows.Forms.Label addNewCarModelFieldLabel;
        private System.Windows.Forms.Label addNewCarBrandFieldLabel;
        private System.Windows.Forms.TextBox addNewCarYearField;
        private System.Windows.Forms.TextBox addNewCarModelField;
        private System.Windows.Forms.TextBox addNewCarBrandField;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.Button deleteCarButton;
        private System.Windows.Forms.Label deleteCarIdLabel;
        private System.Windows.Forms.TextBox DeleteCarIdField;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.TextBox updateCarNewDataField;
        private System.Windows.Forms.Label updateCarNewDataLabel;
        private System.Windows.Forms.RadioButton updateCarOwnerIdRadioButton;
        private System.Windows.Forms.RadioButton updateCarColorRadioButton;
        private System.Windows.Forms.RadioButton updateCarPlateNumberRadioButton;
        private System.Windows.Forms.Label updateCarIdFieldLabel;
        private System.Windows.Forms.Button updateCarButton;
        private System.Windows.Forms.TextBox updateCarIdField;
        private System.Windows.Forms.RadioButton updateCarYearRadioButton;
        private System.Windows.Forms.RadioButton updateCarModelRadioButton;
        private System.Windows.Forms.RadioButton updateCarBrandRadioButton;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.Button loadOwnerIdButton;
        private System.Windows.Forms.Label loadOwnerIdLabel;
        private System.Windows.Forms.TextBox loadOwnerIdField;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.Button addNewOwnerButton;
        private System.Windows.Forms.Label newOwnerSurnameLabel;
        private System.Windows.Forms.Label addOwnerNameLabel;
        private System.Windows.Forms.TextBox newOwnerSurnameField;
        private System.Windows.Forms.TextBox newOwnerNameField;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.Button deleteOwnerIdButton;
        private System.Windows.Forms.Label deleteOwnerIdLabel;
        private System.Windows.Forms.TextBox deleteOwnerIdFIeld;
        private System.Windows.Forms.TabPage tabPage16;
        private System.Windows.Forms.Label updateOwnerNewDataLabel;
        private System.Windows.Forms.TextBox updateOwnerNewDataField;
        private System.Windows.Forms.RadioButton updateOwnerSurnameRadioButton;
        private System.Windows.Forms.RadioButton updateOwnerNameRadioButton;
        private System.Windows.Forms.Label updateOwnerIdLabel;
        private System.Windows.Forms.Button updateOwnerButton;
        private System.Windows.Forms.TextBox updateOwnerIdField;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button addSampleDataButton;
        private System.Windows.Forms.Button loadAllDataButton;
        private System.Windows.Forms.TabPage tabPage17;
        private System.Windows.Forms.Label loadedGarageBuildingNumberField;
        private System.Windows.Forms.Label loadedGarageStreetField;
        private System.Windows.Forms.Label loadedGarageCityField;
        private System.Windows.Forms.Label loadedGarageIdField;
        private System.Windows.Forms.Label loadGarageBuildingNumberLabel;
        private System.Windows.Forms.Label loadedGarageStreetLabel;
        private System.Windows.Forms.Label loadedGarageCityLabel;
        private System.Windows.Forms.Label loadedGarageIdLabel;
        private System.Windows.Forms.Label addGarageResultLabel;
        private System.Windows.Forms.Label addNewGarageResultField;
        private System.Windows.Forms.Label deleteGarageResultField;
        private System.Windows.Forms.Label deleteGarageResultLabel;
        private System.Windows.Forms.Label updateGarageResultField;
        private System.Windows.Forms.Label updateGarageResultLabel;
        private System.Windows.Forms.Label loadGarageResultField;
        private System.Windows.Forms.Label loadGarageResultLabel;
        private System.Windows.Forms.Label loadedCarOwnerIdField;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label loadedCarColorFIeld;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label loadedCarPlateNumberField;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label loadedCarYearField;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label loadedCarModelField;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label loadedCarBrandField;
        private System.Windows.Forms.Label loadedCarBrandLabel;
        private System.Windows.Forms.Label loadedCarIdField;
        private System.Windows.Forms.Label loadedCarIdLabel;
        private System.Windows.Forms.Label addCarResultField;
        private System.Windows.Forms.Label addCarResultLabel;
        private System.Windows.Forms.Label deleteCarResultField;
        private System.Windows.Forms.Label DeleteCarResultLabel;
        private System.Windows.Forms.Label updateCarResultField;
        private System.Windows.Forms.Label updateCarResultLabel;
        private System.Windows.Forms.Label loadedOwnerSurnameLabel;
        private System.Windows.Forms.Label loadedOwnerNameField;
        private System.Windows.Forms.Label loadedOwnerIdField;
        private System.Windows.Forms.Label loadedOwnerNameLabel;
        private System.Windows.Forms.Label loadedOwnerIdLabel;
        private System.Windows.Forms.Label loadedOwnerSurnameField;
        private System.Windows.Forms.Label addNewOwnerResultField;
        private System.Windows.Forms.Label addNewOwnerResultLabel;
        private System.Windows.Forms.Label updateOwnerResultField;
        private System.Windows.Forms.Label updateOwnerResultLabel;
        private System.Windows.Forms.Label deleteOwnerResultField;
        private System.Windows.Forms.Label deleteOwnerResultLabel;
        private System.Windows.Forms.Label loadCarResultField;
        private System.Windows.Forms.Label loadCarResultLabel;
        private System.Windows.Forms.Label loadOwnerResultField;
        private System.Windows.Forms.Label loadOwnerResultLabel;
        private System.Windows.Forms.TreeView loadAllDataTreeView;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
    }
}

